package bingogame;
import java.util.Scanner;

/**
 * @author 6283898
 * 
 * Title: BingoGame
 * 
 * Semester: COP 3804 - Spring 2022
 * Lecturer's Name: Professor Charters
 */
public class BingoGame {

    public static int totalGamesWon = 0;
    public static BingoCard myCard;
    
   
   /** 
     * Description: Will randomly generate 50 numbers 1 - 75 and test to see if they lie on the bingo card
     * Preconditions: A bingo card that has been filled with random values (see: constructor for Bingo Card)
     * Postcondition: Changes anywhere from all to none of the integers on the bingo card to zeroes
   */
    public static void playGame(){
        for (int i = 0; i < 50; i ++){
            int guess = (int) (Math.random() * 75) + 1;
            myCard.checkBingo(guess);
        }
    }
    
    /** 
     * Description: Checks if the user got bingo and prints out corresponding statements to match
     * Preconditions: A bingo card that has been "played" (see: BingoGame.playGame())
     * Postcondition: totalGamesWon increases by one and a message is printed to standard output
   */
    public static void determineWinner(){
        if(myCard.gotBingo()){
            totalGamesWon++;
            System.out.println("You Won!");
        }
        else{
            System.out.println("Sorry, you did not win this time.");
        }
    }
    
    
    public static void main(String[] args) {
        String playAgain = "yes";
        Scanner keyboard = new Scanner(System.in);
      
   
        
        do{
            myCard = new BingoCard();
            playGame();
            System.out.println(myCard.toString());
            determineWinner();
            System.out.println("Would you like to play again?");
            playAgain = keyboard.nextLine();
        } while (playAgain.equalsIgnoreCase("yes"));
        
        System.out.println(totalGamesWon);
        
    }
    
}
